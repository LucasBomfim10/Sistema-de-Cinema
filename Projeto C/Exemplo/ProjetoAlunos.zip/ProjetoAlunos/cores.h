

/*  cores
0 - Preto
1 - Azul
2 - Verde
3 - Verde-�gua
4 - Vermelho
5 - Roxo
6 - Amarelo
7 - Branco
8 - Cinza
9 - Azul claro
A - Verde Claro
B - Verde-�gua claro
C - Vermelho Claro
D - Lil�s
E - Amarelo Claro
F - Branco Brilhante
*/
